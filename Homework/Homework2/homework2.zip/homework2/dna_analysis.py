# Name: ...
# CSE 160
# Homework 2: DNA analysis

# This program reads DNA sequencer output and computes statistics, such as
# the GC content.  Run it from the command line like this:
#   python dna_analysis.py myfile.fastq
#
# For teaching purposes, a few more comments than normal have been added 
# to explain in detail what some Python constructs are doing.

# The sys module supports reading files, command-line arguments, etc.
import sys

# Function to convert the contents of dna_filename into a string of nucleotides
def filename_to_string(dna_filename):
    """ 
    dna_filename - the name of a file in expected file format 
    Expected file format is: Starting with the second line of the file, 
    every fourth line contains nucleotides.  
    The function will read in all lines from the file containing nucleotides, 
    concatenate them all into a single string, and return that string.
    """

    # A file object from which data can be read.
    inputfile = open(dna_filename)

    # ADD YOUR CODE HERE

def countGC(nucleotides):
    # ADD YOUR CODE HERE

if __name__ == "__main__":
    # Check if the user provided an argument
    if len(sys.argv) < 2:
        print "You must supply a file name as an argument when running this program."
        sys.exit(2)

    # Save the 1st argument provided by the user, as a string.
    # Note: sys.argv[0] is the name of the program itself (dna_analysis.py)
    filename = sys.argv[1]

    # Open the file and read in all nucleotides into a single string of letters
    nucleotides = filename_to_string(filename)

    total_count = countGC(nucleotides)

    # You can add more assertions here to check properties that you think
    # should be true about your results. If the condition listed is false,
    # then the given message will be printed.
    assert total_count == len(nucleotides), "total_count != length of nucleotides"
